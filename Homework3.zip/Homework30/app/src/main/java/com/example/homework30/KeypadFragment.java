package com.example.homework30;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.View;
import android.view.LayoutInflater;
import android.widget.Button;
import android.view.ViewGroup;

public class KeypadFragment extends Fragment {
    private NoteDisplayFragment noteDisplayFragment;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_keypad, container, false);

        // Alphabet Buttons
        int[] alphaIds = new int[] {R.id.btnA, R.id.btnB, R.id.btnC, R.id.btnD, R.id.btnE, R.id.btnF,
                R.id.btnG, R.id.btnH, R.id.btnI, R.id.btnJ, R.id.btnK, R.id.btnL,
                R.id.btnM, R.id.btnN, R.id.btnO, R.id.btnP, R.id.btnQ, R.id.btnR,
                R.id.btnS, R.id.btnT, R.id.btnU, R.id.btnV, R.id.btnW, R.id.btnX,
                R.id.btnY, R.id.btnZ};

        for (int id : alphaIds) {
            Button btn = view.findViewById(id);
            String letter = btn.getText().toString();
            btn.setOnClickListener(v -> onKeyPressed(letter));
        }

        // Number Buttons
        int[] numIds = new int[] {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5,
                R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};

        for (int id : numIds) {
            Button btn = view.findViewById(id);
            String number = btn.getText().toString();
            btn.setOnClickListener(v -> onKeyPressed(number));
        }

        // Special Characters
        int[] specialCharIds = new int[] {R.id.btnExclamation, R.id.btnAt, R.id.btnHash, R.id.btnDollar,
                R.id.btnPercent, R.id.btnCarat, R.id.btnAmpersand, R.id.btnAsterisk,
                R.id.btnParenOpen, R.id.btnParenClose};

        for (int id : specialCharIds) {
            Button btn = view.findViewById(id);
            String symbol = btn.getText().toString();
            btn.setOnClickListener(v -> onKeyPressed(symbol));
        }

        Button btnBackspace = view.findViewById(R.id.btnBackspace);
        btnBackspace.setOnClickListener(v -> {
            if (noteDisplayFragment == null) {
                noteDisplayFragment = (NoteDisplayFragment) getFragmentManager().findFragmentById(R.id.fragment_note_display_container);
            }

            if (noteDisplayFragment != null) {
                noteDisplayFragment.backspaceText();
            }
        });

        Button btnClear = view.findViewById(R.id.btnClear);
        btnClear.setOnClickListener(v -> {
            if (noteDisplayFragment == null) {
                noteDisplayFragment = (NoteDisplayFragment) getFragmentManager().findFragmentById(R.id.fragment_note_display_container);
            }

            if (noteDisplayFragment != null) {
                noteDisplayFragment.clearText();
            }
        });

        return view;


    }

    private void onKeyPressed(String key) {
        if (noteDisplayFragment == null) {
            noteDisplayFragment = (NoteDisplayFragment) getFragmentManager().findFragmentById(R.id.fragment_note_display_container);
        }

        if (noteDisplayFragment != null) {
            noteDisplayFragment.appendText(key);
        }
    }
}