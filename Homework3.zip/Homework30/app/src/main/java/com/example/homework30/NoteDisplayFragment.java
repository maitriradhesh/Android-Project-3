package com.example.homework30;

import androidx.fragment.app.Fragment;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.os.Bundle;
public class NoteDisplayFragment extends Fragment {
    private TextView tvNote;
    private TextView textView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_note_display, container, false);
        tvNote = view.findViewById(R.id.tvNote);
        textView = view.findViewById(R.id.tvNote);
        return view;
    }

    public void appendText(String text) {
        tvNote.append(text);
    }

    public void backspaceText() {
        String currentText = textView.getText().toString();
        if (currentText.length() > 0) {
            textView.setText(currentText.substring(0, currentText.length() - 1));
        }
    }

    public void clearText() {
        textView.setText("");
    }
}